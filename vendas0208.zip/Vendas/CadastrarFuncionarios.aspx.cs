﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Vendas
{
    public partial class CadastrarFuncionarios : System.Web.UI.Page
    {

        opra op = new opra();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                tboxCpfFuncionario.Focus();
                tboxNmFuncionario.Enabled = false;
                tboxNmRuaFuncionario.Enabled = false;
                tboxCidFuncionario.Enabled = false;
                tboxCepFuncionario.Enabled = false;
                tboxNumCasaFuncionario.Enabled = false;
                tboxTelFuncionario.Enabled = false;
                ddlUfFuncionario.Enabled = false;
                btnInserir.Enabled = false;
                btnLimpar.Enabled = false;
                gvFuncionarios.DataSource = null;
            }
         
           

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("TelaMenu.aspx");
        }

        protected void tbnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();


                //*BD_VendasConnectionString = copia lá do web.config

                con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BDProjetoFinalConnectionString"].ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Select * from funcionarios";
                cmd.Connection = con;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "funcionarios");
                //começa fazer as inserções
                //new SqlCommandBuilder(traz do "da")
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataRow drow = ds.Tables["funcionarios"].NewRow();
                drow["CPF"] = tboxCpfFuncionario.Text;
                drow["nome"] = tboxNmFuncionario.Text;
                drow["Rua"] = tboxNmRuaFuncionario.Text;
                drow["Cidade"] = tboxCidFuncionario.Text;
                drow["cidade"] = tboxCidFuncionario.Text;
                drow["UF"] = ddlUfFuncionario.Text;
                drow["Tel"] = tboxTelFuncionario.Text;
                drow["Numero"] = tboxNumCasaFuncionario.Text;
                drow["CEP"] = tboxCepFuncionario.Text;





                ds.Tables["funcionarios"].Rows.Add(drow);
                da.Update(ds, "funcionarios");
            }
            catch (Exception erro)
            {
                Response.Write("Erro! - " + erro.Message);
            }
        }

        protected void btnLimpar_Click(object sender, EventArgs e)
        {
           
            

            tboxCpfFuncionario.Focus();

            tboxNmFuncionario.Text = "";
            tboxNmRuaFuncionario.Text = "";
            tboxCidFuncionario.Text = "";
            tboxCepFuncionario.Text = "";
            tboxNumCasaFuncionario.Text = "";
            tboxTelFuncionario.Text = "";
        
          

            tboxNmFuncionario.Enabled = false;
            tboxNmRuaFuncionario.Enabled = false;
            tboxCidFuncionario.Enabled = false;
            tboxCepFuncionario.Enabled = false;
            tboxNumCasaFuncionario.Enabled = false;
            tboxTelFuncionario.Enabled = false;
            ddlUfFuncionario.Enabled = false;
            btnInserir.Enabled = false;
            btnLimpar.Enabled = false;
            gvFuncionarios.Enabled = false;
        }

        protected void tboxCpf_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button6_Click(object sender, EventArgs e)
        {

        }

        protected void btnValidar_Click(object sender, EventArgs e)
        {
            Boolean retorno = op.IsCpf(tboxCpfFuncionario.Text);


            if (retorno == true) // habilita quando cpf esta aprovado
            {
                tboxNmFuncionario.Enabled = true;
                tboxNmRuaFuncionario.Enabled = true;
                tboxCidFuncionario.Enabled = true;
                tboxCepFuncionario.Enabled = true;
                tboxNumCasaFuncionario.Enabled = true;
                tboxTelFuncionario.Enabled = true;
                ddlUfFuncionario.Enabled = true;
                btnInserir.Enabled = true;
                btnLimpar.Enabled = true;
                gvFuncionarios.Enabled = true;
                
            }

            else
            {
                tboxCpfFuncionario.Text = "";
                tboxNmFuncionario.Enabled = false;
                tboxNmRuaFuncionario.Enabled = false;
                tboxCidFuncionario.Enabled = false;
                tboxCepFuncionario.Enabled = false;
                tboxNumCasaFuncionario.Enabled = false;
                tboxTelFuncionario.Enabled = false;
                ddlUfFuncionario.Enabled = false;
                btnInserir.Enabled = false;
                btnLimpar.Enabled = false;
                gvFuncionarios.Enabled = false;

            }


            tboxNmFuncionario.Text = "";
            tboxNmRuaFuncionario.Text = "";
            tboxCidFuncionario.Text = "";
            tboxCepFuncionario.Text = "";
            tboxNumCasaFuncionario.Text = "";
            tboxTelFuncionario.Text = "";
       

        }

        protected void tboxNmFuncionario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

