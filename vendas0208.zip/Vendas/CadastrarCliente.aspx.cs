﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Vendas
{
    public partial class CadastrarCliente : System.Web.UI.Page
    {
        opra op = new opra();
        protected void Page_Load(object sender, EventArgs e)
        {

           
            tboxCpf.Focus();
            tboxNmUsuario.Enabled = false;
            tboxNmCliente.Enabled = false;
            tboxNmRua.Enabled = false;
            tboxCidCliente.Enabled = false;
            tboxCepCliente.Enabled = false;
            tboxNmSenha.Enabled = false;
            tboxTelCliente.Enabled = false;
            tboxNumCasa.Enabled = false;
            btnInserir.Enabled = false;
            btnLimpar.Enabled = false;
            gvCliente.DataSource = null;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("TelaMenu.aspx");
        }
        // clicar nos botoes para criar os eventos onclick
        protected void tbnInserir_Click(object sender, EventArgs e)
        {

        }

        protected void btnLimpar_Click(object sender, EventArgs e)
        {
            

            
        }

        protected void tboxCpf_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Boolean retorno = op.IsCpf(tboxCpf.Text);


            if (retorno == true) // habilita quando cpf esta aprovado
            {
                tboxNmCliente.Enabled = true;
                tboxNmRua.Enabled = true;
                tboxCidCliente.Enabled = true;
                tboxCepCliente.Enabled = true;
                tboxNumCasa.Enabled = true;
                tboxTelCliente.Enabled = true;
                ddlUf.Enabled = true;
                btnInserir.Enabled = true;
                btnLimpar.Enabled = true;
                gvCliente.Enabled = true;
                tboxNmUsuario.Enabled = true;
                tboxNmSenha.Enabled = true;

            }

            else
            {
                tboxCpf.Text = "";
                tboxNmCliente.Enabled = false;
                tboxNmRua.Enabled = false;
                tboxCidCliente.Enabled = false;
                tboxCepCliente.Enabled = false;
                tboxNumCasa.Enabled = false;
                tboxTelCliente.Enabled = false;
                ddlUf.Enabled = false;
                btnInserir.Enabled = false;
                btnLimpar.Enabled = false;
                gvCliente.Enabled = false;

            }
        }

        protected void tboxTelCliente_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnLimpar_Click1(object sender, EventArgs e)
        {
            tboxCpf.Focus();

            tboxNmCliente.Text = "";
            tboxNmRua.Text = "";
            tboxCidCliente.Text = "";
            tboxCepCliente.Text = "";
            tboxNumCasa.Text = "";
            tboxTelCliente.Text = "";
            tboxNmUsuario.Text = "";
            tboxNmSenha.Text = "";



        }

        protected void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();


                //*BD_VendasConnectionString = copia lá do web.config

                con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BDProjetoFinalConnectionString"].ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Select * from cliente";
                cmd.Connection = con;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "cliente");
                //começa fazer as inserções
                //new SqlCommandBuilder(traz do "da")
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataRow drow = ds.Tables["cliente"].NewRow();
                drow["nome"] = tboxNmCliente.Text;
                drow["cpf"] = tboxCpf.Text;
                drow["rua"] = tboxNmRua.Text;
                drow["numero"] = tboxNumCasa.Text;
                drow["cidade"] = tboxCidCliente.Text;
                drow["uf"] = ddlUf.Text;
                drow["cep"] = tboxCepCliente.Text;
                drow["telefone"] = tboxTelCliente.Text;
                drow["usuario"] = tboxNmUsuario.Text;
                drow["senha"] = tboxNmSenha.Text;



                ds.Tables["cliente"].Rows.Add(drow);
                da.Update(ds, "cliente");
            }
            catch (Exception erro)
            {
                Response.Write("Erro! - " + erro.Message);
            }


            tboxNmCliente.Text = "";
            tboxNmRua.Text = "";
            tboxCidCliente.Text = "";
            tboxCepCliente.Text = "";
            tboxNumCasa.Text = "";
            tboxTelCliente.Text = "";
            tboxNmUsuario.Text = "";
            tboxNmSenha.Text = "";
        }
    }
}